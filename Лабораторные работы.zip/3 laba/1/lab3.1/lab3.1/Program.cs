﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3_1
{
    class Program
    {
        static void Main(string[] args)
        {
            double price = 500d;
            Console.WriteLine($"Стоимость одного килограмма сыра составляет {price} руб.\n");

            for (double i = 0.1; i < 1.0; i += 0.1)
                Console.WriteLine("Цена за {0} кг.: {1:0.00} руб.", i, price * i);

            Console.ReadLine();
        }
    }
}
