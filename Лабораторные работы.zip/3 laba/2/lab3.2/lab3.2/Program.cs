﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите целое число A: ");
            string s1 = Console.ReadLine();
            uint a = uint.Parse(s1);

            Console.WriteLine("Теперь целое число B: ");
            string s2 = Console.ReadLine();
            uint b = uint.Parse(s2);


            for (uint i = a; i <= b; ++i)
            {
                for (uint j = 0; j < i; ++j)
                {
                    Console.Write(i + " ");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
