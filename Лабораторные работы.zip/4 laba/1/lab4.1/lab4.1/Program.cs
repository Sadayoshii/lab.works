﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lab4_1
{
    class Program
    {
        static void Main(string[] args)

        {
            int[] arrayTask = { 1, 2, -3, -6, -9, 10 };
            Console.WriteLine(
                " \a Максимальное значение массива: {0} \n  Минимальное значение: {1}",
                arrayTask.Max(),
                arrayTask.Min());
        }
    }
}