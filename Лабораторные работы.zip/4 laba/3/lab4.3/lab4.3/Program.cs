﻿using System;
using System.Linq;
class Program { }

namespace lab4_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] msv = new int[20];
            Random r = new Random();
            Console.WriteLine("Исходный массив:");
            for (int i = 0; i < msv.Length; i++)
            {
                msv[i] = r.Next(0, 10);
                Console.Write(msv[i] + " ");
            }
            var msv2 = msv.Where(n => n % 2 != 0);
            Console.WriteLine("\n\nПосле удаления четных:");
            foreach (int i in msv2)
            {
                Console.Write(i + " ");
            }
            Console.ReadKey();
        }
    }
}
