﻿using System;

namespace laba8
{
class Worker
{
    public string name;
    public string surname;
    public string patronymic;
    public int age;
    public string jobtitle;
    public string developmentdep;

    public void GetInfo()
    {
        Console.WriteLine($" Имя: {name}\n Фамилия: {surname}\n Отчество: {patronymic}\n Возраст: {age}\n Должность: {jobtitle}\n Отдел: {developmentdep}");
    }


}
class Program
{
    static void Main(string[] args)
    {
        Worker wrk = new Worker();
        wrk.name = "Evgeniy";
        wrk.surname = "Lemeshov";
        wrk.patronymic = "Grigorievich";
        wrk.age = 19;
        wrk.jobtitle = "Manager";
        wrk.developmentdep = "Sales Department";
        wrk.GetInfo();
        /*Разработать Отдел разработки*/
        Development_department dep = new Development_department();
        dep.department_name = "Departament";
        dep.department_manager = "Lemeshov";
        dep.worker_number = 140;
        dep.GetInfo();
    }
}
class Development_department
{
    public string department_name;
    public string department_manager;
    public int worker_number;


    public void GetInfo()
    {
        Console.WriteLine($" \n Название отдела: {department_name}\n Глава отдела: {department_manager}\n Количество сотрудников: {worker_number}");
    }
}
}