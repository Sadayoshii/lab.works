﻿using System;

namespace lab_1_1
{
    class program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите первое число");
            string S1 = Console.ReadLine();
            int a = int.Parse(S1);

            Console.WriteLine("Введите второе число");
            string S2 = Console.ReadLine();
            int b = int.Parse(S2);

            int c = a + b;

            Console.WriteLine("Ответ:");
            Console.WriteLine(c);
                
        }
    }
}
