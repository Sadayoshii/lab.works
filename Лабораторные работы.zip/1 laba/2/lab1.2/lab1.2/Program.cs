﻿using System;

namespace ConsoleApp11
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y, z;
            bool flag;

            System.Console.WriteLine("Введите число");
            x = int.Parse(System.Console.ReadLine());
            System.Console.WriteLine("Введите число");
            y = int.Parse(System.Console.ReadLine());
            System.Console.WriteLine("Введите число");
            z = int.Parse(System.Console.ReadLine());

            flag = (x > z);
            System.Console.WriteLine(flag);

            flag = (x + 5 > y);
            System.Console.WriteLine(flag);

            flag = ((z > x) || (y > x));
            System.Console.WriteLine(flag);
        }
    }
}