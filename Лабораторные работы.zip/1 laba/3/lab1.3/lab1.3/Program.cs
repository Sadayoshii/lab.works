﻿using System;

namespace ConsoleApp11
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число 1");
            string a = Console.ReadLine();
            Console.WriteLine("Введите число 2");
            string b = Console.ReadLine();

            Console.WriteLine($" Без замены {a}-{b}");

            (a, b) = (b, a);

            Console.WriteLine($" С заменой {a}-{b}");
        }
    }
}
