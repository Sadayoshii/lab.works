﻿namespace LR_10_Двусвязные_Списки
{
    public class Item<T>
    {
        public Item(T name, T quantity, T id, T dateOfManufacture)
        {
            Name = name;
            Quantity = quantity;
            ID = id;
            DateOfManufacture = dateOfManufacture;
        }

        public T Name { get; set; }
        public T Quantity { get; set; }
        public T ID { get; set; }
        public T DateOfManufacture { get; set; }
        public Item<T> Previous { get; set; }
        public Item<T> Next { get; set; }
    }
}