﻿using System;

namespace lr5_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количесво строк: ");
            int n = int.Parse(Console.ReadLine());

            Console.Write("Введите количество столбцов: ");
            int m = int.Parse(Console.ReadLine());

            int[,] Nums = new int[n, m];
            int[,] Nums2 = new int[n, m];

            Console.WriteLine();
            Console.WriteLine("Введите значения массива: ");
            for (int i = 0; i < Nums.GetLength(0); i++)
            {
                for (int j = 0; j < Nums.GetLength(1); j++)
                {
                    Console.Write($"Строка: {i} Столбец: {j} = ");
                    Nums[i, j] = int.Parse(Console.ReadLine());
                }
            }

            Console.WriteLine();
            Console.Write("Введите квадрат какого либо числа: ");
            int sqrt = int.Parse(Console.ReadLine());

            double res;
            for (int i = 0; i < Nums.GetLength(0); i++)
            {
                for (int j = 0; j < Nums.GetLength(1); j++)
                {
                    res = Nums[i, j] * Nums[i, j];
                    if (res == sqrt)
                    {
                        Nums2[i, j] = Nums[i, j];
                    }
                }
            }

            Console.WriteLine();
            Console.Write($"Элементы массива, " +
                $"которые являются квадратами числа {sqrt}: ");
            for (int i = 0; i < Nums2.GetLength(0); i++)
            {
                for (int j = 0; j < Nums2.GetLength(1); j++)
                {
                    if (Nums2[i, j] == 0)
                    {
                        continue;
                    }
                    else
                    {
                        Console.Write($"{Nums[i, j]} ");
                    }
                }
            }
            Console.ReadKey();
        }
    }
}
