﻿using System;

namespace lab5_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество студентов: ");
            int N = int.Parse(Console.ReadLine());

            int[,] Students = new int[N, 4];

            Console.WriteLine();

            Console.WriteLine("Введите оценки учеников за экзамен: ");
            for (int i = 0; i < Students.GetLength(0); i++)
            {
                Console.WriteLine();
                for (int j = 0; j < Students.GetLength(1); j++)
                {
                    Console.Write($"{j + 1} оценка {i + 1} студента:  ");
                    Students[i, j] = int.Parse(Console.ReadLine());
                }
            }

            double AllPoints = 0;
            int NoProgress = 0;
            for (int i = 0; i < Students.GetLength(0); i++)
            {
                double Score;
                int grade = 0;

                for (int j = 0; j < Students.GetLength(1); j++)
                {
                    grade += Students[i, j];
                }

                Score = grade / 4;
                AllPoints += Score;

                if (Score < 3)
                {
                    NoProgress += 1;
                }
            }

            Console.WriteLine();
            double GroupScore = AllPoints / N;
            Console.WriteLine($"Средний балл группы: {Math.Round(GroupScore, 2)}");
            Console.WriteLine($"Количество неуспевающих студентов: {NoProgress}");
            Console.ReadKey();
        }
    }
}
