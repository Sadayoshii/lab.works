﻿using System;

namespace lr5_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количесво строк: ");
            int n = int.Parse(Console.ReadLine());

            Console.Write("Введите количество столбцов: ");
            int m = int.Parse(Console.ReadLine());

            int[,] Nums = new int[n, m];


            Console.WriteLine();
            Console.WriteLine("Введите значения массива: ");
            for (int i = 0; i < Nums.GetLength(0); i++)
            {
                for (int j = 0; j < Nums.GetLength(1); j++)
                {
                    Console.Write($"Строка: {i} Столбец: {j} = ");
                    Nums[i, j] = int.Parse(Console.ReadLine());
                }
            }

            int summa = 0;
            int proizvedenie = 1;
            for (int i = 0; i < Nums.GetLength(0); i++)
            {
                for (int j = 0; j < Nums.GetLength(1); j++)
                {
                    int mod = Nums[i, j] % 3;
                    int mod2 = Nums[i, j] % 5;
                    if (mod == 0)
                    {
                        summa += Nums[i, j];
                        proizvedenie *= Nums[i, j];
                    }
                    if (mod2 == 0)
                    {
                        summa += Nums[i, j];
                        proizvedenie *= Nums[i, j];
                    }
                }
                Console.WriteLine();
            }

            Console.WriteLine($"Cуммa элементов, кратных 3 и 5: {summa}");
            Console.WriteLine($"Произведение элементов, кратных 3 и 5: {proizvedenie}");
            Console.ReadKey();
        }
    }
}
